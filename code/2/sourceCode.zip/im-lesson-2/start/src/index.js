import './main.css'

document.write('Hello React/Redux!')